##### zoteroTypeSchemaData.js

This file is generated in the Zotero client with `Zotero.openInViewer('chrome://zotero/content/tools/build_typeSchemaData.html')`
and then loaded by `cachedTypes.js` in this repository.
